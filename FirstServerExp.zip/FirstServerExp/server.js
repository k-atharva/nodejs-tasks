const express = require("express");
const path = require("path");
const app = express();

app.get('/',function(request, response){
   response.sendFile(path.join(__dirname,'./html_files','index.html')) ;
});

app.get('*', function(request, response){});

app.listen(3000, function(){}
);
    