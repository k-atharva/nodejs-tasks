const express = require("express");
const app = express();

app.get("/test1",(req, res) => {
    
        res.send ('This is First API using Express')
    })
    app.get("/test2",(req, res) => {
        res.send({
            name: "Atharva"
        })

    })
    
app.listen(766, function(){
    console.log("Server is running on port 766")

})


